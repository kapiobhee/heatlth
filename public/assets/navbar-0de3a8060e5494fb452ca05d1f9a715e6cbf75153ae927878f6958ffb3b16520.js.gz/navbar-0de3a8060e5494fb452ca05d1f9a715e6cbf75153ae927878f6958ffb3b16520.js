(function() {
  $(document).on('ready', function() {
    return $('.button-collapse').sideNav();
  });

}).call(this);
